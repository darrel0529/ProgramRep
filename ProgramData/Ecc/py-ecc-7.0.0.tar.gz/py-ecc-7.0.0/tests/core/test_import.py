def test_import():
    import py_ecc  # noqa: F401

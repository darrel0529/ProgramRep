Changelog
---------

0.2.6
+++++

**Bugfixes**

- Display help when ``requires.io`` called without argument

0.2.5
+++++

**Features**

- Add ``parse`` command line to parse a single requirements file

0.2.4
+++++

**Bugfixes**

- Keep detected path patterns when computing the remote basename of a requirement file

0.2.3
+++++

**Bugfixes**

- Encoding issue in Python 3 for commands ``update-branch`` and ``update-tag``


# -*- coding: utf-8 -*-
REQUIREMENTS = 'requirements'
SETUP = 'setup.py'
TOX = 'tox'
BUILDOUT = 'buildout'
TYPES = (REQUIREMENTS, SETUP, TOX, BUILDOUT)
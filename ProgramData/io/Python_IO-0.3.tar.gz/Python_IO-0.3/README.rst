===
PyIO: a basic user input-output program.
===

Still working on documentation.

Installing Python IO:
===

Install Python-IO by running the following command in your Python terminal:
``
pip install Python-IO
``
It doesn't matter what case you type 'Python-IO' in.
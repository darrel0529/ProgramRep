# !/usr/bin/env python3
# !/usr/bin/env python2
import subprocess
subprocess.call(["python script.py"])
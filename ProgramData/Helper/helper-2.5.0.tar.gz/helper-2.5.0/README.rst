Helper
======

Helper is a development library for quickly writing configurable applications and daemons.

Platforms Supported
-------------------

Python 2.7+, 3.2+ on Unix (POSIX) Platforms

Documentation
-------------

Documentation is available at https://helper.readthedocs.io

Installation
------------

helper is available as a package from pypi.python.org for development purposes.

Normally, helper would be installed as a dependency from another application or
package.

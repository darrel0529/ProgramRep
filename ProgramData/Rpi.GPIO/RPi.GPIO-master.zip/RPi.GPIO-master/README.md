# RPi.GPIO
RPi.GPIO (A Python module to control the GPIO on a Raspberry Pi) for Banana Pi 

"""Network event detector backends for aio_net_events."""

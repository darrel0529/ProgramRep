****
Swap
****

.. automodule:: networkx.algorithms.swap
.. autosummary::
   :toctree: generated/

   double_edge_swap
   directed_edge_swap
   connected_double_edge_swap


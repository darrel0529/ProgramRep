Node Classification
===================

.. automodule:: networkx.algorithms.node_classification
.. autosummary::
   :toctree: generated/

   harmonic_function
   local_and_global_consistency

"""a sets of exceptions we made in order to make them more comprehensible and make the errors and debuggin more clear"""

import sys
import os

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), os.path.pardir)))

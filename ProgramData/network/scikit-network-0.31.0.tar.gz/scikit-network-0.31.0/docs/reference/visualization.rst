.. _visualization:

Visualization
*************

Visualization tools.

Graphs
------

.. autofunction:: sknetwork.visualization.graphs.svg_graph

.. autofunction:: sknetwork.visualization.graphs.svg_bigraph

Dendrograms
-----------

.. autofunction:: sknetwork.visualization.dendrograms.svg_dendrogram

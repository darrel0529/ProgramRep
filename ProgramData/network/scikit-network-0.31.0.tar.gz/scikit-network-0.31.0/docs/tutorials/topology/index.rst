Topology
********


.. toctree::

   connected_components
   cycles
   core_decomposition
   cliques
   isomorphism

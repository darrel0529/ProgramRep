Embedding
*********


.. toctree::

   spectral
   svd
   gsvd
   pca
   random_projection
   louvain_embedding
   louvain_hierarchy
   spring
   forceatlas




Visualization
*************


.. toctree::

    graphs
    paths
    dendrograms
    pie_charts


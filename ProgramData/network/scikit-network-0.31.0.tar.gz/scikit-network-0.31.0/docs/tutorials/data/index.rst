.. _DataTag:

Data
****

.. toctree::

    load_data
    load_collection
    models
    toy_graphs
    save

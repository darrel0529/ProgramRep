Link prediction
***************


.. toctree::

    nn

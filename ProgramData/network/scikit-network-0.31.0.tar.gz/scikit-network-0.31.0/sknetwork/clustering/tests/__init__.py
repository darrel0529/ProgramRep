"""tests for clustering"""

"""Tests for linalg"""

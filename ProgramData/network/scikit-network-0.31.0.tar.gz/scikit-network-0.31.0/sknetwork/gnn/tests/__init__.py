"""tests for gnn"""

"""tests for link prediction"""

"""tests for path module"""

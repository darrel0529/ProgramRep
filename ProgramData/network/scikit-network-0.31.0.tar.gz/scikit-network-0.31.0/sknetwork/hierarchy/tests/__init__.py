"""tests for hierarchy"""

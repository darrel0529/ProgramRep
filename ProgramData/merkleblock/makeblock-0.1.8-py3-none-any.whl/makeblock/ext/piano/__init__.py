from makeblock import mBuild
piano = mBuild.Piano()
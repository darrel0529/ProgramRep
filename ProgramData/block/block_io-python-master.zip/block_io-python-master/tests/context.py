import os
import sys
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'block_io')))

from block_io import BlockIo
from bitcoinutils_patches import *
import bitcoinutils

                                   

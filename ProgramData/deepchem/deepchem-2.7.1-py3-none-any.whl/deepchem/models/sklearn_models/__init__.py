# flake8: ignore
from deepchem.models.sklearn_models.sklearn_model import SklearnModel

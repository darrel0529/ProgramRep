# flake8: noqa
try:
  from deepchem.metalearning.maml import MAML, MetaLearner
except ModuleNotFoundError:
  pass

# flake8: noqa
from deepchem.models.gbdt_models.gbdt_model import GBDTModel
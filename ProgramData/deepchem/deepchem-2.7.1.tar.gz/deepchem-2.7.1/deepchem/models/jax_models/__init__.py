# flake8:noqa
from deepchem.models.jax_models.jax_model import JaxModel
from deepchem.models.jax_models.pinns_model import PINNModel
